If you want to contribute to Theano, have a look at the instructions here:
http://deeplearning.net/software/theano/dev_start_guide.html
