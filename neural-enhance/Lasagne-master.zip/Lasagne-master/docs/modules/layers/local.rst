Local layers
------------

.. automodule:: lasagne.layers.local

.. currentmodule:: lasagne.layers

.. autoclass:: LocallyConnected2DLayer
    :members:
