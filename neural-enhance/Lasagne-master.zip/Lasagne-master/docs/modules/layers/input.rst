Network input
-------------

.. automodule:: lasagne.layers.input

.. currentmodule:: lasagne.layers

.. autoclass:: InputLayer
   :members:

