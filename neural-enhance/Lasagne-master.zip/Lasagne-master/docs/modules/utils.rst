:mod:`lasagne.utils`
====================

.. automodule:: lasagne.utils

.. autodata:: int_types
   :annotation: = (numbers.Integral, np.integer)
.. autofunction:: floatX
.. autofunction:: shared_empty
.. autofunction:: as_theano_expression
.. autofunction:: collect_shared_vars
.. autofunction:: one_hot
.. autofunction:: unique
.. autofunction:: compute_norms
.. autofunction:: create_param
